**备注**

- 台式机请移除`SSDT-Disable-DGPU.aml`

